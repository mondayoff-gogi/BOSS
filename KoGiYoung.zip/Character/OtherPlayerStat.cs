﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OtherPlayerStat : MonoBehaviour
{
    public int index;
    public float MaxHp;
    public float Hp;
    public float MaxMp;
    public float Mp;
    public float MagicAttackPower;
    public float PhysicalAttackPower;
    public float critical;
    // Start is called before the first frame update
    void Start()
    {
        
    }

}
